﻿using BDQN.Models;

namespace BDQN.IDAL
{
    public interface IUsersDal : IBaseDal<Users>
    {
    }
}
