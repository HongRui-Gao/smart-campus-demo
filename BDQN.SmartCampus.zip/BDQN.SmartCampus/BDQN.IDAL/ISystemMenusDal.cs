﻿using BDQN.Models;

namespace BDQN.IDAL
{
    public interface ISystemMenusDal : IBaseDal<SystemMenus>
    {
    }
}
