﻿using BDQN.Models;

namespace BDQN.IDAL
{
    public interface IRolesDal : IBaseDal<Roles>
    {
    }
}
