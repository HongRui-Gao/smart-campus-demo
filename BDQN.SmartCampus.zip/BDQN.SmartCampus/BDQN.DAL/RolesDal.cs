﻿using BDQN.IDAL;
using BDQN.Models;
namespace BDQN.DAL
{
    public class RolesDal : BaseDal<Roles> , IRolesDal
    {
        //每次创建数据库实现类的时候,必须把它所对应的接口内容带进来
    }
}
