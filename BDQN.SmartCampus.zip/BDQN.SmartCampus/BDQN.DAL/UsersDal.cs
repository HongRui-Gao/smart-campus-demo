﻿using BDQN.IDAL;
using BDQN.Models;

namespace BDQN.DAL
{
    public class UsersDal : BaseDal<Users> , IUsersDal
    {
    }
}
