﻿using BDQN.IDAL;
using BDQN.Models;

namespace BDQN.DAL
{
    public class SystemMenusDal : BaseDal<SystemMenus> , ISystemMenusDal
    {
    }
}
